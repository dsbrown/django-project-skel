default_app_config = 'reporting.apps.ReportingConfig'

from django.core.management.base import BaseCommand, CommandError
from reporting.models import Site, AvailabilityZone, Region, SiteAddress
from os.path import isfile
from openpyxl import load_workbook

class Command(BaseCommand):
    help = 'Closes the specified poll for voting'

    def add_arguments(self, parser):
        parser.add_argument('path')

    def handle(self, *args, **options):
        path = options['path']
        #check if file is valid before continuing
        if isfile(path):
            print 'Processing file - %s' % path
            self.parse(path)
        else:
            raise CommandError('Path "%s" is not a valid file' % path)

    def parse(self, path):
        #open file and iterate through rows  
        print 'Parsing file '
        wb = load_workbook(filename=path)
        print wb
        sheet = wb['Sheet']
        print sheet
        for row in sheet.iter_rows(row_offset=1):
            self.process_row(row)

    def process_row(self, row):
        """
            0 Site Code A 
            1 Number  
            2 Region  
            3 AZ RegionName   
            4 Address 
            5 City    
            6 State   
            7 Country 
            8 Postal Code 
            9 Building Owner  
            10 Page Three.Cluster  
            11 Page Three.Landlord 
            12 Page Three.Lease Holder 
            13 Service Type
        """
        #check if we have a site code defined 
        site_code = row[0].value
        if site_code:
            # get or find the Site object  
            site, created = Site.objects.get_or_create(code=site_code)
            print "site code = "+ site_code

            availability_zone = row[3].value
            #if zone is defined, get or create the record to set reference 
            #to Site object 
            if availability_zone: 
                zone, create = AvailabilityZone.objects.get_or_create(code=availability_zone)
                site.availability_zone = zone
                #print "availability_zone = "+availability_zone
                #print zone.pk

            street = row[4].value
            city = row[5].value
            state = row[6].value
            country = row[7].value
            address = SiteAddress.objects.get_or_create(street=street, city=city, state=state, country=country)
            if street and city and state and country: 
                address, created = SiteAddress.objects.get_or_create(street=street, city=city, state=state, country=country)
                print address
            service_types = row[13].value
            
            #split and add site to each of these
            if service_types:
                print "service_types" 
                print service_types
                for t in service_types.split(','):
                    print t
                    #this_type = Service.objects.get_or_create(service=t)

            region_code = row[2].value 
            if region_code:
                region, create = Region.objects.get_or_create(code=region_code)
                site.region = region
                #print "region_code = "+region_code

            site.save()

            print "=========================="
            

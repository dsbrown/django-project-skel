from django.core.management.base import BaseCommand, CommandError
from reporting.models import Site, AvailabilityZone, Region
from os.path import isfile

class Command(BaseCommand):
    help = 'Closes the specified poll for voting'

    def add_arguments(self, parser):
        parser.add_argument('path')

    def handle(self, *args, **options):
        path = options['path']
        #check if file is valid before continuing
        if isfile(path):
            print 'Processing file - %s' % path
            self.parse(path)
        else:
            raise CommandError('Path "%s" is not a valid file' % path)

    def parse(self, path):
        #open file and iterate through rows  
        print 'Parsing file '

    def process_row(self, row):
        site_code = 'SFO008'
        agile_Code = 'agile code'
        zone, create = AvailabilityZone.objects.get_or_create(code="az code")
        street = "123 5th Ave"
        city = "Seattle"
        state = "WA"
        country = "USA"
        address = SiteAddress.objects.get_or_create(street=street, city=city, state=state, country=country)
        
        service_types = "CloudFront,CXA"
        #split and add site to each of these

        region_code = 'NA'
        region, create = Region.objects.get_or_create(code=region_code)

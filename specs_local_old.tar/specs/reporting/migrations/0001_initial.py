# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models
import django.db.models.deletion


class Migration(migrations.Migration):

    initial = True

    dependencies = [
    ]

    operations = [
        migrations.CreateModel(
            name='AvailabilityZone',
            fields=[
                ('id', models.AutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
                ('code', models.TextField()),
                ('description', models.TextField()),
            ],
            options={
                'ordering': ['code'],
                'verbose_name': 'Cluster',
            },
        ),
        migrations.CreateModel(
            name='ColoProvider',
            fields=[
                ('id', models.AutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
                ('name', models.CharField(blank=True, max_length=90)),
                ('portal_url', models.URLField(blank=True, max_length=2048)),
                ('gibd_owner', models.CharField(blank=True, max_length=64)),
                ('pmt_owner', models.CharField(blank=True, max_length=64)),
            ],
            options={
                'ordering': ['name'],
                'verbose_name': 'Vendor Colo Provider',
            },
        ),
        migrations.CreateModel(
            name='Contact',
            fields=[
                ('id', models.AutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
                ('first_name', models.CharField(blank=True, max_length=90)),
                ('middle_name', models.CharField(blank=True, max_length=90)),
                ('last_name', models.CharField(blank=True, max_length=90)),
                ('title', models.CharField(blank=True, max_length=90)),
                ('email_address', models.EmailField(blank=True, max_length=254)),
                ('office_phone', models.CharField(blank=True, max_length=45)),
                ('mobile_phone', models.CharField(blank=True, max_length=45)),
                ('street', models.CharField(blank=True, max_length=90)),
                ('city', models.CharField(blank=True, max_length=45)),
                ('state', models.CharField(blank=True, max_length=45)),
                ('country', models.CharField(blank=True, max_length=45)),
                ('amazon_id', models.CharField(blank=True, max_length=90)),
                ('notes', models.TextField()),
                ('alternate', models.ForeignKey(blank=True, null=True, on_delete=django.db.models.deletion.CASCADE, to='reporting.Contact')),
            ],
            options={
                'ordering': ['last_name', 'first_name'],
                'verbose_name': 'Contact Information',
            },
        ),
        migrations.CreateModel(
            name='Contract',
            fields=[
                ('id', models.AutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
                ('negotioations', models.DecimalField(blank=True, decimal_places=2, default=0, max_digits=4)),
                ('reporting', models.DecimalField(blank=True, decimal_places=2, default=0, max_digits=4)),
                ('compliance', models.DecimalField(blank=True, decimal_places=2, default=0, max_digits=4)),
                ('sla_violations', models.DecimalField(blank=True, decimal_places=2, default=0, max_digits=4)),
            ],
        ),
        migrations.CreateModel(
            name='ContractWeights',
            fields=[
                ('id', models.AutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
                ('date', models.DateField(blank=True)),
                ('negotioations', models.DecimalField(blank=True, decimal_places=3, default=0, max_digits=5)),
                ('reporting', models.DecimalField(blank=True, decimal_places=3, default=0, max_digits=5)),
                ('compliance', models.DecimalField(blank=True, decimal_places=3, default=0, max_digits=5)),
                ('sla_violations', models.DecimalField(blank=True, decimal_places=3, default=0, max_digits=5)),
            ],
            options={
                'ordering': ['date'],
                'verbose_name': 'Contract Scaling Weights',
            },
        ),
        migrations.CreateModel(
            name='Engineering',
            fields=[
                ('id', models.AutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
                ('colo_audit_score', models.DecimalField(blank=True, decimal_places=2, default=0, max_digits=4)),
                ('non_impacting_events', models.DecimalField(blank=True, decimal_places=2, default=0, max_digits=4)),
                ('impacting_events', models.DecimalField(blank=True, decimal_places=2, default=0, max_digits=4)),
                ('dc_tiering_level', models.DecimalField(blank=True, decimal_places=2, default=0, max_digits=4)),
            ],
        ),
        migrations.CreateModel(
            name='EngineeringWeights',
            fields=[
                ('id', models.AutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
                ('date', models.DateField(blank=True)),
                ('colo_audit_score', models.DecimalField(blank=True, decimal_places=3, default=0, max_digits=5)),
                ('non_impacting_events', models.DecimalField(blank=True, decimal_places=3, default=0, max_digits=5)),
                ('impacting_events', models.DecimalField(blank=True, decimal_places=3, default=0, max_digits=5)),
                ('dc_tiering_level', models.DecimalField(blank=True, decimal_places=3, default=0, max_digits=5)),
            ],
            options={
                'verbose_name': 'Engineering Scaling Weights',
            },
        ),
        migrations.CreateModel(
            name='Price',
            fields=[
                ('id', models.AutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
                ('payment_terms', models.DecimalField(blank=True, decimal_places=2, default=0, max_digits=4)),
                ('invoice_performance', models.DecimalField(blank=True, decimal_places=2, default=0, max_digits=4)),
                ('average_first_to_last_quote_delta', models.DecimalField(blank=True, decimal_places=2, default=0, max_digits=4)),
                ('pue', models.DecimalField(blank=True, decimal_places=2, default=0, max_digits=4)),
                ('per_unit_cost', models.DecimalField(blank=True, decimal_places=2, default=0, max_digits=4)),
            ],
        ),
        migrations.CreateModel(
            name='PriceWeights',
            fields=[
                ('id', models.AutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
                ('date', models.DateField(blank=True)),
                ('payment_terms', models.DecimalField(blank=True, decimal_places=3, default=0, max_digits=5)),
                ('invoice_performance', models.DecimalField(blank=True, decimal_places=3, default=0, max_digits=5)),
                ('average_first_to_last_quote_delta', models.DecimalField(blank=True, decimal_places=3, default=0, max_digits=5)),
                ('pue', models.DecimalField(blank=True, decimal_places=3, default=0, max_digits=5)),
                ('per_unit_cost', models.DecimalField(blank=True, decimal_places=3, default=0, max_digits=5)),
            ],
            options={
                'verbose_name': 'Price Scaling Weights',
            },
        ),
        migrations.CreateModel(
            name='Region',
            fields=[
                ('id', models.AutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
                ('code', models.CharField(choices=[('NA', 'North America'), ('SA', 'South America'), ('EM', 'Europe, the Middle East and Africa'), ('AP', 'Asia Pacific')], max_length=2)),
                ('description', models.CharField(max_length=128)),
            ],
            options={
                'ordering': ['code'],
                'verbose_name': 'Region',
            },
        ),
        migrations.CreateModel(
            name='Scale',
            fields=[
                ('id', models.AutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
                ('account_management', models.DecimalField(blank=True, decimal_places=2, default=0, max_digits=4)),
                ('contact_list', models.DecimalField(blank=True, decimal_places=2, default=0, max_digits=4)),
                ('communications', models.DecimalField(blank=True, decimal_places=2, default=0, max_digits=4)),
                ('staffing_model_level', models.DecimalField(blank=True, decimal_places=2, default=0, max_digits=4)),
                ('mop', models.DecimalField(blank=True, decimal_places=2, default=0, max_digits=4)),
                ('eop', models.DecimalField(blank=True, decimal_places=2, default=0, max_digits=4)),
                ('black_gray_day_compliance', models.DecimalField(blank=True, decimal_places=2, default=0, max_digits=4)),
                ('helpdesk_noc', models.DecimalField(blank=True, decimal_places=2, default=0, max_digits=4)),
                ('helpdesk_noc_issue_request_resolution_time', models.DecimalField(blank=True, decimal_places=2, default=0, max_digits=4)),
                ('maintenance_notifications', models.DecimalField(blank=True, decimal_places=2, default=0, max_digits=4)),
                ('event_incident_notifications', models.DecimalField(blank=True, decimal_places=2, default=0, max_digits=4)),
                ('post_event_incident_reporting', models.DecimalField(blank=True, decimal_places=2, default=0, max_digits=4)),
                ('bms', models.DecimalField(blank=True, decimal_places=2, default=0, max_digits=4)),
                ('number_of_sites_not_used_by_aws', models.DecimalField(blank=True, decimal_places=2, default=0, max_digits=4)),
                ('rack_positions_available', models.DecimalField(blank=True, decimal_places=2, default=0, max_digits=4)),
                ('portal', models.DecimalField(blank=True, decimal_places=2, default=0, max_digits=4)),
            ],
        ),
        migrations.CreateModel(
            name='ScaleWeights',
            fields=[
                ('id', models.AutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
                ('date', models.DateField(blank=True)),
                ('account_management', models.DecimalField(blank=True, decimal_places=3, default=0, max_digits=5)),
                ('contact_list', models.DecimalField(blank=True, decimal_places=3, default=0, max_digits=5)),
                ('communications', models.DecimalField(blank=True, decimal_places=3, default=0, max_digits=5)),
                ('staffing_model_level', models.DecimalField(blank=True, decimal_places=3, default=0, max_digits=5)),
                ('mop', models.DecimalField(blank=True, decimal_places=3, default=0, max_digits=5)),
                ('eop', models.DecimalField(blank=True, decimal_places=3, default=0, max_digits=5)),
                ('black_gray_day_compliance', models.DecimalField(blank=True, decimal_places=3, default=0, max_digits=5)),
                ('helpdesk_noc', models.DecimalField(blank=True, decimal_places=3, default=0, max_digits=5)),
                ('helpdesk_noc_issue_request_resolution_time', models.DecimalField(blank=True, decimal_places=3, default=0, max_digits=5)),
                ('maintenance_notifications', models.DecimalField(blank=True, decimal_places=3, default=0, max_digits=5)),
                ('event_incident_notifications', models.DecimalField(blank=True, decimal_places=3, default=0, max_digits=5)),
                ('post_event_incident_reporting', models.DecimalField(blank=True, decimal_places=3, default=0, max_digits=5)),
                ('bms', models.DecimalField(blank=True, decimal_places=3, default=0, max_digits=5)),
                ('number_of_sites_not_used_by_aws', models.DecimalField(blank=True, decimal_places=3, default=0, max_digits=5)),
                ('rack_positions_available', models.DecimalField(blank=True, decimal_places=3, default=0, max_digits=5)),
                ('portal', models.DecimalField(blank=True, decimal_places=3, default=0, max_digits=5)),
            ],
            options={
                'verbose_name': 'Scalability Scaling Weights',
            },
        ),
        migrations.CreateModel(
            name='Security',
            fields=[
                ('id', models.AutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
                ('contact_list', models.DecimalField(blank=True, decimal_places=3, default=0, max_digits=5)),
                ('average_response_time', models.DecimalField(blank=True, decimal_places=3, default=0, max_digits=5)),
                ('issues', models.DecimalField(blank=True, decimal_places=3, default=0, max_digits=5)),
                ('sla_violations', models.DecimalField(blank=True, decimal_places=3, default=0, max_digits=5)),
                ('staffing_model_level', models.DecimalField(blank=True, decimal_places=3, default=0, max_digits=5)),
            ],
        ),
        migrations.CreateModel(
            name='SecurityWeights',
            fields=[
                ('id', models.AutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
                ('date', models.DateField(blank=True)),
                ('contact_list', models.DecimalField(blank=True, decimal_places=3, default=0, max_digits=5)),
                ('average_response_time', models.DecimalField(blank=True, decimal_places=3, default=0, max_digits=5)),
                ('issues', models.DecimalField(blank=True, decimal_places=3, default=0, max_digits=5)),
                ('sla_violations', models.DecimalField(blank=True, decimal_places=3, default=0, max_digits=5)),
                ('staffing_model_level', models.DecimalField(blank=True, decimal_places=3, default=0, max_digits=5)),
            ],
            options={
                'verbose_name': 'Security Scaling Weights',
            },
        ),
        migrations.CreateModel(
            name='Service',
            fields=[
                ('id', models.AutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
                ('service', models.CharField(choices=[('POP', 'POP'), ('CF', 'Cloudfront'), ('TX', 'Transit'), ('DX', 'Direct Connect'), ('EC2', 'EC2 Compute'), ('HPC', 'High Performance Computing'), ('VPC', 'Virtual Private Cloud'), ('PROD', 'AWS Production'), ('CORP', 'Corporate IT Production'), ('GPS', 'Global Payment Service'), ('S3', 'S3 Storage'), ('CMT', 'CMT')], max_length=3)),
                ('description', models.CharField(max_length=45)),
            ],
            options={
                'ordering': ['description'],
                'verbose_name': 'Data Center Service Provided',
            },
        ),
        migrations.CreateModel(
            name='Site',
            fields=[
                ('id', models.AutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
                ('code', models.CharField(blank=True, max_length=7)),
                ('agile_no', models.CharField(blank=True, max_length=10)),
                ('project_name', models.CharField(blank=True, max_length=64)),
                ('tier_level', models.IntegerField(blank=True, default=0)),
                ('status', models.CharField(choices=[('PRD', 'In Production'), ('DEV', 'In Development')], max_length=3)),
                ('availability_zone', models.ForeignKey(blank=True, null=True, on_delete=django.db.models.deletion.SET_NULL, to='reporting.AvailabilityZone')),
                ('colo_audit_owner', models.ForeignKey(blank=True, on_delete=django.db.models.deletion.CASCADE, related_name='colo_audit_owner', to='reporting.Contact')),
                ('dceo_owner', models.ForeignKey(blank=True, on_delete=django.db.models.deletion.CASCADE, related_name='dceo_owner', to='reporting.Contact')),
                ('dco_owner', models.ForeignKey(blank=True, on_delete=django.db.models.deletion.CASCADE, related_name='dco_owner', to='reporting.Contact')),
                ('event_contact', models.ForeignKey(blank=True, on_delete=django.db.models.deletion.CASCADE, related_name='event_contact', to='reporting.Contact')),
            ],
            options={
                'ordering': ['code'],
                'verbose_name': 'Site',
            },
        ),
        migrations.CreateModel(
            name='SiteAddress',
            fields=[
                ('id', models.AutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
                ('street', models.CharField(blank=True, max_length=90)),
                ('city', models.CharField(blank=True, max_length=45)),
                ('state', models.CharField(blank=True, max_length=45)),
                ('country', models.CharField(blank=True, max_length=45)),
                ('latitude', models.FloatField(blank=True, null=True)),
                ('longitude', models.FloatField(blank=True, null=True)),
            ],
        ),
        migrations.CreateModel(
            name='Specs',
            fields=[
                ('id', models.AutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
                ('published_date', models.DateField(blank=True)),
                ('start_date', models.DateField(blank=True, null=True)),
                ('end_date', models.DateField(blank=True, null=True)),
                ('contract', models.ForeignKey(blank=True, null=True, on_delete=django.db.models.deletion.CASCADE, to='reporting.Contract')),
                ('engineering', models.ForeignKey(blank=True, null=True, on_delete=django.db.models.deletion.CASCADE, to='reporting.Engineering')),
                ('price', models.ForeignKey(blank=True, null=True, on_delete=django.db.models.deletion.CASCADE, to='reporting.Price')),
                ('scale', models.ForeignKey(blank=True, null=True, on_delete=django.db.models.deletion.CASCADE, to='reporting.Scale')),
                ('security', models.ForeignKey(blank=True, null=True, on_delete=django.db.models.deletion.CASCADE, to='reporting.Security')),
                ('site_code', models.ForeignKey(on_delete=django.db.models.deletion.CASCADE, to='reporting.Site')),
            ],
            options={
                'ordering': ['site_code', 'published_date'],
                'verbose_name': 'Top level SPECS data for site',
            },
        ),
        migrations.CreateModel(
            name='SpecsWeights',
            fields=[
                ('id', models.AutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
                ('date', models.DateField(blank=True)),
                ('score_a', models.DecimalField(blank=True, decimal_places=3, default=0, max_digits=5)),
                ('score_b', models.DecimalField(blank=True, decimal_places=3, default=0, max_digits=5)),
                ('score_c', models.DecimalField(blank=True, decimal_places=3, default=0, max_digits=5)),
                ('score_d', models.DecimalField(blank=True, decimal_places=3, default=0, max_digits=5)),
                ('score_f', models.DecimalField(blank=True, decimal_places=3, default=0, max_digits=5)),
                ('overall_weight_security', models.DecimalField(blank=True, decimal_places=3, default=0, max_digits=5)),
                ('overall_weight_pricing', models.DecimalField(blank=True, decimal_places=3, default=0, max_digits=5)),
                ('overall_weight_engineering', models.DecimalField(blank=True, decimal_places=3, default=0, max_digits=5)),
                ('overall_weight_contract', models.DecimalField(blank=True, decimal_places=3, default=0, max_digits=5)),
                ('overall_weight_scalability', models.DecimalField(blank=True, decimal_places=3, default=0, max_digits=5)),
            ],
            options={
                'verbose_name': 'Overall Scaling Weights',
            },
        ),
        migrations.AddField(
            model_name='site',
            name='location',
            field=models.ForeignKey(blank=True, null=True, on_delete=django.db.models.deletion.SET_NULL, to='reporting.SiteAddress'),
        ),
        migrations.AddField(
            model_name='site',
            name='maintenance_contact',
            field=models.ForeignKey(blank=True, on_delete=django.db.models.deletion.CASCADE, related_name='maintenance_contact', to='reporting.Contact'),
        ),
        migrations.AddField(
            model_name='site',
            name='payment_support_owner',
            field=models.ForeignKey(blank=True, on_delete=django.db.models.deletion.CASCADE, related_name='payment_support_owner', to='reporting.Contact'),
        ),
        migrations.AddField(
            model_name='site',
            name='provider',
            field=models.ManyToManyField(blank=True, to='reporting.ColoProvider'),
        ),
        migrations.AddField(
            model_name='site',
            name='security_owner',
            field=models.ForeignKey(blank=True, on_delete=django.db.models.deletion.CASCADE, related_name='security_owner', to='reporting.Contact'),
        ),
        migrations.AddField(
            model_name='site',
            name='site_assessment_owner',
            field=models.ForeignKey(blank=True, on_delete=django.db.models.deletion.CASCADE, related_name='site_assessment_owner', to='reporting.Contact'),
        ),
        migrations.AddField(
            model_name='site',
            name='site_ops_contact',
            field=models.ForeignKey(blank=True, on_delete=django.db.models.deletion.CASCADE, related_name='site_ops_contact', to='reporting.Contact'),
        ),
        migrations.AddField(
            model_name='site',
            name='site_security_contact',
            field=models.ForeignKey(blank=True, on_delete=django.db.models.deletion.CASCADE, related_name='site_security_contact', to='reporting.Contact'),
        ),
        migrations.AddField(
            model_name='service',
            name='sites',
            field=models.ManyToManyField(to='reporting.Site'),
        ),
        migrations.AddField(
            model_name='coloprovider',
            name='primary_account_contact',
            field=models.ForeignKey(blank=True, on_delete=django.db.models.deletion.CASCADE, related_name='primary_account_contact', to='reporting.Contact'),
        ),
        migrations.AddField(
            model_name='coloprovider',
            name='primary_operations_contact',
            field=models.ForeignKey(blank=True, on_delete=django.db.models.deletion.CASCADE, related_name='primary_operations_contact', to='reporting.Contact'),
        ),
        migrations.AddField(
            model_name='coloprovider',
            name='primary_sales_contact',
            field=models.ForeignKey(blank=True, on_delete=django.db.models.deletion.CASCADE, related_name='primary_sales_contact', to='reporting.Contact'),
        ),
        migrations.AddField(
            model_name='coloprovider',
            name='primary_security_contact',
            field=models.ForeignKey(blank=True, on_delete=django.db.models.deletion.CASCADE, related_name='primary_security_contact', to='reporting.Contact'),
        ),
        migrations.AddField(
            model_name='availabilityzone',
            name='region',
            field=models.ForeignKey(on_delete=django.db.models.deletion.CASCADE, to='reporting.Region'),
        ),
    ]

from django.contrib import admin
from .models import *

admin.site.register(Region)
admin.site.register(AvailabilityZone)
admin.site.register(ColoProvider)
admin.site.register(Site)
admin.site.register(Specs)
admin.site.register(Security)
admin.site.register(Price)
admin.site.register(Engineering)
admin.site.register(Contract)
admin.site.register(Scale)

